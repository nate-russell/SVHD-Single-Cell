library(testthat)
library(largeVis)

test_check("largeVis")
