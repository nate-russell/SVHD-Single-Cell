%% Load data
filename_label = sprintf('Load labels');
load(filename_label);

csvfilename = sprintf('Load input csv data');
csvdata = csvread(csvfilename);
data = csvdata';

%% Clustering
n = size(data,1);
nLabels = 24;
nClusters = 100;

f_final_results = zeros(nLabels+1+nLabels,nClusters-4);

% k: number of clusters
for k = 2 : nClusters
    [idx, centroid] = kmeans(data, k);
    clusterStat = zeros(nLabels,k);   % number of each label (row) for each cluster (column) 
    for i = 1 : n
        temp = clusterStat(labels(i),idx(i));
        clusterStat(labels(i),idx(i)) = temp + 1;
    end
    
    % Find F-measure
    sumCol = sum(clusterStat);
    R_denominator = repmat(sumCol,[nLabels,1]);
    sumRow = sum(clusterStat,2);
    P_denominator = repmat(sumRow,[1,k]);

    R = clusterStat./R_denominator;
    P = clusterStat./P_denominator;
    
    F_measure = 2*(R.*P)./(R+P);

    f = F_measure;
    f(isnan(f)) = 0;
    
    % Hungarian algorithm
    costMatrix = 1 - f;
    [assignment, cost] = munkres(costMatrix);
    
    f_each_label = zeros(nLabels,1);
    
    for j = 1 : size(assignment,2)
        if 0 ~= assignment(j)
            f_each_label(j) = f(j,assignment(j));
        end 
    end
    
    f_all_labels = sum(f_each_label);
    f_final_results(:,k-1) = [f_each_label ; f_all_labels ; assignment'];
end

[m,i] = max(f_final_results(25,:));

filename_result = sprintf('output file path');
save(filename_result,'f_final_results');

%% Plot (Visualization)
cmap = uint32([...
115,82,68
194,150,130
98,122,157
87,108,67
133,128,177
103,189,170
214,126,44
80,91,166
193,90,99
94,60,108
157,188,64
224,163,46
56,61,150
70,148,73
175,54,60
231,199,31
187,86,149
8,133,161
243,243,242
200,200,200
160,160,160
122,122,121
85,85,85
52,52,52]);
imshow(cmap);

figure(1)
gscatter(plot_data(:,1), plot_data(:,2), plot_labels, cmap);
h = legend('Location', 'northeastoutside');
set(h, 'FontSize', 9)
axis([-100,100,-100,100])
axis([-30,30,-30,40])

figure(2)
gscatter(plot_viSNE_data(:,1), plot_viSNE_data(:,2), plot_labels, cmap);
h = legend('Location', 'northeastoutside');
set(h, 'FontSize', 9)
axis([-120,120,-120,120])
axis([-30,30,-30,40])
