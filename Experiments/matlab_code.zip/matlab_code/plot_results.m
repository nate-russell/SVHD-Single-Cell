%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% largeVis with dim 2
loadmat1_largeVis = load('ours_dim2_f\\dim2_data1_f.mat');
loadmat2_largeVis = load('ours_dim2_f\\dim2_data2_f.mat');
loadmat3_largeVis = load('ours_dim2_f\\dim2_data3_f.mat');
loadmat4_largeVis = load('ours_dim2_f\\dim2_data4_f.mat');
loadmat5_largeVis = load('ours_dim2_f\\dim2_data5_f.mat');
loadmat6_largeVis = load('ours_dim2_f\\dim2_data6_f.mat');
loadmat7_largeVis = load('ours_dim2_f\\dim2_data7_f.mat');
loadmat8_largeVis = load('ours_dim2_f\\dim2_data8_f.mat');
loadmat9_largeVis = load('ours_dim2_f\\dim2_data9_f.mat');
loadmat10_largeVis = load('ours_dim2_f\\dim2_data10_f.mat');

% Average
f1_largeVis1 = loadmat1_largeVis.f_final_results(1:24,:);
f1_largeVis2 = loadmat2_largeVis.f_final_results(1:24,:);
f1_largeVis3 = loadmat3_largeVis.f_final_results(1:24,:);
f1_largeVis4 = loadmat4_largeVis.f_final_results(1:24,:);
f1_largeVis5 = loadmat5_largeVis.f_final_results(1:24,:);
f1_largeVis6 = loadmat6_largeVis.f_final_results(1:24,:);
f1_largeVis7 = loadmat7_largeVis.f_final_results(1:24,:);
f1_largeVis8 = loadmat8_largeVis.f_final_results(1:24,:);
f1_largeVis9 = loadmat9_largeVis.f_final_results(1:24,:);
f1_largeVis10 = loadmat10_largeVis.f_final_results(1:24,:);
Mat_f1_largeVis = (f1_largeVis1+f1_largeVis2+f1_largeVis3+f1_largeVis4+f1_largeVis5+f1_largeVis6+f1_largeVis7+f1_largeVis8+f1_largeVis9+f1_largeVis10)/10;
Avg_f1_largeVis = sum(Mat_f1_largeVis);
[max_largeVis, idx_largeVis] = max(Avg_f1_largeVis);

% Median
[f1_largeVis, i1_largeVis] = max(loadmat1_largeVis.f_final_results(25,:));
[f2_largeVis, i2_largeVis] = max(loadmat2_largeVis.f_final_results(25,:));
[f3_largeVis, i3_largeVis] = max(loadmat3_largeVis.f_final_results(25,:));
[f4_largeVis, i4_largeVis] = max(loadmat4_largeVis.f_final_results(25,:));
[f5_largeVis, i5_largeVis] = max(loadmat5_largeVis.f_final_results(25,:));
[f6_largeVis, i6_largeVis] = max(loadmat6_largeVis.f_final_results(25,:));
[f7_largeVis, i7_largeVis] = max(loadmat7_largeVis.f_final_results(25,:));
[f8_largeVis, i8_largeVis] = max(loadmat8_largeVis.f_final_results(25,:));
[f9_largeVis, i9_largeVis] = max(loadmat9_largeVis.f_final_results(25,:));
[f10_largeVis, i10_largeVis] = max(loadmat10_largeVis.f_final_results(25,:));
f_largeVis = [f1_largeVis i1_largeVis; f2_largeVis i2_largeVis; f3_largeVis i3_largeVis; f4_largeVis i4_largeVis; f5_largeVis i5_largeVis; ...
                f6_largeVis i6_largeVis; f7_largeVis i7_largeVis; f8_largeVis i8_largeVis; f9_largeVis i9_largeVis; f10_largeVis i10_largeVis];

med_f_largeVis = median(f_largeVis(:,1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% viSNE
loadmat1_viSNE = load('viSNE_F\\viSNE1_f.mat');
loadmat2_viSNE = load('viSNE_F\\viSNE2_f.mat');
loadmat3_viSNE = load('viSNE_F\\viSNE3_f.mat');
loadmat4_viSNE = load('viSNE_F\\viSNE4_f.mat');
loadmat5_viSNE = load('viSNE_F\\viSNE5_f.mat');
loadmat6_viSNE = load('viSNE_F\\viSNE6_f.mat');
loadmat7_viSNE = load('viSNE_F\\viSNE7_f.mat');
loadmat8_viSNE = load('viSNE_F\\viSNE8_f.mat');
loadmat9_viSNE = load('viSNE_F\\viSNE9_f.mat');
loadmat10_viSNE = load('viSNE_F\\viSNE10_f.mat');

% Average
f1_viSNE1 = loadmat1_viSNE.f_final_results(1:24,:);
f1_viSNE2 = loadmat2_viSNE.f_final_results(1:24,:);
f1_viSNE3 = loadmat3_viSNE.f_final_results(1:24,:);
f1_viSNE4 = loadmat4_viSNE.f_final_results(1:24,:);
f1_viSNE5 = loadmat5_viSNE.f_final_results(1:24,:);
f1_viSNE6 = loadmat6_viSNE.f_final_results(1:24,:);
f1_viSNE7 = loadmat7_viSNE.f_final_results(1:24,:);
f1_viSNE8 = loadmat8_viSNE.f_final_results(1:24,:);
f1_viSNE9 = loadmat9_viSNE.f_final_results(1:24,:);
f1_viSNE10 = loadmat10_viSNE.f_final_results(1:24,:);
Mat_f1_viSNE = (f1_viSNE1+f1_viSNE2+f1_viSNE3+f1_viSNE4+f1_viSNE5+f1_viSNE6+f1_viSNE7+f1_viSNE8+f1_viSNE9+f1_viSNE10)/10;
Avg_f1_viSNE = sum(Mat_f1_viSNE);
[max_viSNE, idx_viSNE] = max(Avg_f1_viSNE);

% Median
[f1_viSNE, i1_viSNE] = max(loadmat1_viSNE.f_final_results(25,:));
[f2_viSNE, i2_viSNE] = max(loadmat2_viSNE.f_final_results(25,:));
[f3_viSNE, i3_viSNE] = max(loadmat3_viSNE.f_final_results(25,:));
[f4_viSNE, i4_viSNE] = max(loadmat4_viSNE.f_final_results(25,:));
[f5_viSNE, i5_viSNE] = max(loadmat5_viSNE.f_final_results(25,:));
[f6_viSNE, i6_viSNE] = max(loadmat6_viSNE.f_final_results(25,:));
[f7_viSNE, i7_viSNE] = max(loadmat7_viSNE.f_final_results(25,:));
[f8_viSNE, i8_viSNE] = max(loadmat8_viSNE.f_final_results(25,:));
[f9_viSNE, i9_viSNE] = max(loadmat9_viSNE.f_final_results(25,:));
[f10_viSNE, i10_viSNE] = max(loadmat10_viSNE.f_final_results(25,:));
f_viSNE = [f1_viSNE i1_viSNE; f2_viSNE i2_viSNE; f3_viSNE i3_viSNE; f4_viSNE i4_viSNE; f5_viSNE i5_viSNE; ...
            f6_viSNE i6_viSNE; f7_viSNE i7_viSNE; f8_viSNE i3_viSNE; f9_viSNE i9_viSNE; f10_viSNE i10_viSNE];

med_f_viSNE = median(f_viSNE(:,1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
plot(1:99, Avg_f1_largeVis);
hold on
plot(1:99, Avg_f1_viSNE);

xhandle = xlabel('Number of clusters'); % x-axis label
yhandle = ylabel('Sum of average F1-measures for 24 labels'); % y-axis label
leg = legend('our method-2d','viSNE','Location','southeast');
set(xhandle,'FontSize',14);
set(yhandle,'FontSize',14);
set(leg,'FontSize',14);